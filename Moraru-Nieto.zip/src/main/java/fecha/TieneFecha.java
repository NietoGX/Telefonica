package fecha;

import java.io.Serializable;
import java.util.Calendar;

public interface TieneFecha {
    Calendar getFecha();
}
