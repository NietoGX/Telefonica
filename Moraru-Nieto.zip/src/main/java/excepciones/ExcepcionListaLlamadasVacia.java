package excepciones;

public class ExcepcionListaLlamadasVacia extends Exception {
    public ExcepcionListaLlamadasVacia() {
        super("Lista llamadas vacia");
    }
}
