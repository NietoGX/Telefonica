package excepciones;

public class ExcepcionFechas extends Throwable {
    public ExcepcionFechas() {
        super("Fechas incorrectas");
    }
}
