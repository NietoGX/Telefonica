package excepciones;

public class ExcepcionListaFacturasVacia extends Exception {
    public ExcepcionListaFacturasVacia() {
        super("Lista facturas vacia");
    }
}
